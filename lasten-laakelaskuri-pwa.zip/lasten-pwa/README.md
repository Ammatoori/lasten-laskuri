# Lasten lääkelaskuri — PWA-prototyyppi

**EI KLIINISEEN KÄYTTÖÖN.** Lähdetiedot ja kaikki laskelmat tulee tarkistaa riippumattomasti ennen potilaskäyttöä.

## GitHub Pages -julkaisu

1. Luo GitHubiin julkinen repository, esim. `lasten-laakelaskuri`.
2. Lataa **tämän kansion sisältö** repositoryn juureen (`index.html`, `app.js`, `style.css`, `drugs.json`, `sw.js`, `manifest.webmanifest` ja `icons/`).
3. Avaa repositoryn **Settings → Pages → Build and deployment → Deploy from a branch**.
4. Valitse `main` ja `/ (root)`, paina **Save**.
5. Julkaistu osoite on `https://KÄYTTÄJÄNIMI.github.io/lasten-laakelaskuri/`.
6. Asenna sovellus selaimen valikosta **Lisää Koti-valikkoon / Install app**.

Käynnistys paikallisesti (kansiossa): `python -m http.server 8000`, ja avaa `http://localhost:8000`.

## Toiminnot

- Lääkeryhmä + haku + lääkevalinta
- Painoon perustuva annos (valittu alkuperäisen annosvälin yläraja)
- Tilavuus pyöristetään lähimpään 0,1 ml:aan; annoksen ylittäessä laskennallisen rajan näytetään iso **YLI!!!**
- Laskennallinen tilavuus, pyöristetty kokonaisannos ja painokilokohtainen annos
- Nestetarve (Holliday–Segar), erilliset vuorokausi- ja tuntikaavat, kuten Excelissä
- Offline-asennus ja tumma tila

## Lähteen tulkintaa / rajoituksia

- Excelistä: **Lasten lääkelaskuri.xlsx**, vain `Taul1`, lääkeryhmät riveiltä 16–85 ja nestetarve I11:S19.
- `drugs.json` tallentaa alkuperäiset annostelu- ja vahvuusmerkkijonot, lähderivin ja Excel-kaavatekstit tarkastusta varten.
- Midatsolaamin ja diatsepaamin `max ... mg` -raja on lähteen tekstissä, mutta alkuperäiset Excel-kaavat eivät rajoita tulosta. Prototyyppi soveltaa tekstirajaa ja näyttää tarkistusvaroituksen.
- DHBP:n 0,5 mg enimmäismäärä on alkuperäisessä kaavassa; prototyyppi soveltaa sitä.
- Ondansetronin vuorokausirajaa ei käytetä automaattisesti, koska lähdemerkintä `max 4-8mg/vrk` on epäselvä.
- Naloxonin lähdeannostelu on `0.01-0.02 mg/mg`, joten automaattinen laskenta on poistettu.
- Rivit, joille ei ole yksiselitteistä nestemäistä annoslaskua, näkyvät ilman laskennallista ml-tulosta.
- Alle 0,1 ml:n laskennallisissa tilavuuksissa annetaan erillinen mittaustarkkuusvaroitus.
- Ikätieto on prototyypissä vain syöte, eikä se muuta annosta. Ikärajojen ja vasta-aiheiden validointi puuttuu.
- Paikallinen välimuisti päivittyy muokkaamalla `sw.js`-tiedoston `CACHE`-versiota.

**Tarvittava jatkovalidointi**: vähintään jokaisen lääkerivin annosyksiköt ja valmistemuodot, enimmäisannokset, paino- ja ikärajoitukset, lääkevahvuudet, ristiriitaiset lähdehuomautukset sekä regressiotestit alkuperäistä taulukkoa vasten.
