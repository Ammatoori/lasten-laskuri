const $=id=>document.getElementById(id);
const fmt=(n,d=2)=>Number.isFinite(n)?new Intl.NumberFormat('fi-FI',{maximumFractionDigits:d,minimumFractionDigits:0}).format(n):'—';
let drugs=[];
let current=null;
const categories=['Kaikki','Esilääkitys','Induktio','Kipulääkkeet','Antidootit','Pahoinvointi','Hätälääkkeet'];
const weight=()=>Number($('weight').value);
const validWeight=()=> $('weight').value!==''&&Number.isFinite(weight())&&weight()>0&&weight()<=300;
function loadSettings(){try{const x=JSON.parse(localStorage.getItem('lasten-settings')||'{}');if(x.theme)document.documentElement.dataset.theme=x.theme;}catch{}}
function saveSettings(){try{localStorage.setItem('lasten-settings',JSON.stringify({theme:document.documentElement.dataset.theme||'light'}))}catch{}}
function updateStatus(){$('connection').textContent=navigator.onLine?'● Online':'● Offline';}
function selectDrug(){const category=$('category').value;const q=$('search').value.toLocaleLowerCase('fi').trim();const shown=drugs.filter(d=>(category==='Kaikki'||d.category===category)&&d.name.toLocaleLowerCase('fi').includes(q));const prev=$('drug').value;$('drug').replaceChildren(...shown.map(d=>new Option(`${d.name}${d.calculable?'':' · tarkista'}`,d.id)));if(shown.some(d=>d.id===prev))$('drug').value=prev;$('count').textContent=`${shown.length} lääkettä`;renderDrug();}
function ceilWarning(value){return value>0.00000001;}
function calculate(d,w){
 if(!d.calculable||!d.concentrationMgMl||!Number.isFinite(d.maxDose))return null;
 const divider=d.denominator==='10kg'?10:d.denominator==='5kg'?5:1;
 let theoreticalMg=w*d.maxDose/divider*(d.doseUnit==='ug'?0.001:1);
 if(d.maxAbsoluteMg!=null)theoreticalMg=Math.min(theoreticalMg,d.maxAbsoluteMg);
 const unroundedMl=theoreticalMg/d.concentrationMgMl;
 const roundedMl=Math.floor(unroundedMl*10+0.5+1e-10)/10;
 const actualMg=roundedMl*d.concentrationMgMl;
 const over=actualMg>theoreticalMg+1e-9;
 const scale=d.doseUnit==='ug'?1000:1;
 const denomScale=divider;
 return {theoreticalMg,unroundedMl,roundedMl,actualMg,over,actualPerKg:actualMg*scale/w*denomScale,idealPerKg:theoreticalMg*scale/w*denomScale,unit:`${d.doseUnit}/${d.denominator}`,deltaMl:roundedMl-unroundedMl,underMeasurable:unroundedMl<0.1};
}
const htmlEsc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function renderDrug(){const d=drugs.find(x=>x.id===$('drug').value);current=d;$('weightError').textContent=(!validWeight()&&$('weight').value!=='')?'Anna paino väliltä 0–300 kg.':'';if(!d){$('drugResult').innerHTML='<div class="empty">Ei hakutuloksia.</div>';return}
 const head=`<div class="resulthead"><h3>${htmlEsc(d.name)}</h3><p>${htmlEsc(d.category)} · Excel-rivi ${d.sourceRow}</p></div><div class="infochips"><span class="chip">Annostelu: ${htmlEsc(d.doseText||'—')}</span><span class="chip">Vahvuus: ${htmlEsc(d.strength||'—')}</span></div>`;
 let sourceNotes='';if(d.note)sourceNotes+=`<div class="warning">Lähteen huomautus: ${htmlEsc(d.note)}</div>`;if(d.extra)sourceNotes+=`<div class="warning">Lähteen lisätieto: ${htmlEsc(d.extra)}</div>`;if(d.issue)sourceNotes+=`<div class="warning critical"><strong>TARKISTA LÄHDE:</strong> ${htmlEsc(d.issue)}</div>`;
 if(!d.calculable){$('drugResult').innerHTML=head+`<div class="empty">Automaattinen ml-laskenta ei ole käytettävissä tälle riville.</div>`+sourceNotes;return}
 if(!validWeight()){$('drugResult').innerHTML=head+'<div class="empty">Syötä potilaan paino nähdäksesi laskelman.</div>'+sourceNotes;return}
 const c=calculate(d,weight());
 const overText=c.over?`<div class="overword" role="alert">YLI!!!</div>`:'';
 const caution=c.underMeasurable?'<div class="warning critical">Laskennallinen tilavuus on alle 0,1 ml. Tavallinen 0,1 ml:n mittaustarkkuus ei riitä; älä tulkitse 0,0 ml:aa annosteluohjeeksi.</div>':'';
 const overNote=c.over?`<div class="warning critical"><strong>YLITYS:</strong> Pyöristys ylittää laskennallisen enimmäisannoksen ${fmt((c.actualMg-c.theoreticalMg)*(d.doseUnit==='ug'?1000:1),3)} ${htmlEsc(d.doseUnit)}. Ei annostelusuositus.</div>`:'';
 const limit=d.maxAbsoluteMg!=null?`<div class="warning">Laskennassa käytetty absoluuttinen enimmäismäärä: ${fmt(d.maxAbsoluteMg,2)} mg. ${htmlEsc(d.sourceCap||'')}</div>`:'';
 $('drugResult').innerHTML=head+`<div class="dosebox ${c.over?'over':''}">${overText}<div class="dosecaption">Pyöristetty tilavuus · 0,1 ml</div><div class="mainvol">${fmt(c.roundedMl,1)} ml</div><div class="small">Laskennallinen: ${fmt(c.unroundedMl,4)} ml</div></div><div class="resultgrid"><div class="tile"><span>Pyöristetty annos</span><strong class="${c.over?'red':''}">${fmt(c.actualPerKg,4)} ${htmlEsc(c.unit)}</strong></div><div class="tile"><span>Laskennallinen annos</span><strong>${fmt(c.idealPerKg,4)} ${htmlEsc(c.unit)}</strong></div><div class="tile"><span>Pyöristetty kokonaisannos</span><strong>${fmt(c.actualMg*(d.doseUnit==='ug'?1000:1),3)} ${htmlEsc(d.doseUnit)}</strong></div><div class="tile"><span>Laskennallinen kokonaisannos</span><strong>${fmt(c.theoreticalMg*(d.doseUnit==='ug'?1000:1),3)} ${htmlEsc(d.doseUnit)}</strong></div></div>${overNote}${caution}${limit}${sourceNotes}<p class="disclaimer">Laskenta perustuu annosteluvälin ylärajaan. Pyöristetty tulos ei ole itsenäinen hoito-ohje.</p>`;
}
function renderFluid(){if(!validWeight()){$('fluidResult').innerHTML='<div class="empty">Syötä potilaan paino nähdäksesi nestetarpeen.</div>';return}const w=weight();const day=w<10?w*100:w<=20?1000+(w-10)*50:1500+(w-20)*20;const hour=w<10?w*4:w<=20?40+(w-10)*2:60+(w-20);$('fluidResult').innerHTML=`<div class="resultgrid"><div class="tile"><span>Nestetarve / vrk</span><div class="fluidnumber">${fmt(day,1)}</div><b>ml/vrk</b></div><div class="tile"><span>Nestetarve / h</span><div class="fluidnumber">${fmt(hour,1)}</div><b>ml/h</b></div></div><div class="warning">Painoluokka: ${w<10?'alle 10 kg':w<=20?'10–20 kg':'yli 20 kg'}. Vuorokausi- ja tuntiarvot on laskettu erillisillä lähdekaavoilla, joten ne eivät välttämättä ole täsmälleen samat jaettuna 24:llä.</div>`;}
async function init(){loadSettings();updateStatus();window.addEventListener('online',updateStatus);window.addEventListener('offline',updateStatus);
 $('category').replaceChildren(...categories.map(c=>new Option(c,c)));try{const r=await fetch('./drugs.json');if(!r.ok)throw Error('Tietoa ei löydy');drugs=await r.json();selectDrug()}catch(e){$('drugResult').textContent='Lääkedata ei latautunut. Käytä verkkopalvelinta / GitHub Pagesia.'}
 $('category').addEventListener('change',selectDrug);$('search').addEventListener('input',selectDrug);$('drug').addEventListener('change',renderDrug);
 ['weight','age'].forEach(k=>$(k).addEventListener('input',()=>{renderDrug();renderFluid()}));
 document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(t=>{t.classList.toggle('active',t===b);t.setAttribute('aria-selected',String(t===b))});$('drugTab').classList.toggle('hidden',b.dataset.tab!=='drug');$('fluidTab').classList.toggle('hidden',b.dataset.tab!=='fluid');renderFluid()}));
 $('theme').addEventListener('click',()=>{document.documentElement.dataset.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';saveSettings()});renderFluid();
 if('serviceWorker'in navigator && location.protocol!=='file:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
init();
